import React, { Component } from 'react';
import logo from '../logo.svg';
import './MediaCard.scss';


class MediaCard extends Component {
  render() {
    return (
      <div className="card">
        <header className="card-header">
          <h1 className="card__name"> Alex Guerrero</h1>
          <img src={logo} className="card__img" alt="personal pic" />
          <p className="card__date">Lunes 26 de Junio de 2017</p>
        </header>
        <main className="card-main">
          <p className="card__des"> Est duis laboris nisi tempor. Anim ea culpa labore incididunt culpa velit elit culpa occaecat aute proident eu ipsum. Ut esse commodo quis eiusmod eu cillum. Ex magna quis sint officia est nulla labore do proident mollit. Id est ipsum et commodo adipisicing non proident. Consequat veniam ex velit veniam eu est aliqua elit nisi amet consectetur duis.</p>
        </main>
        <footer className="card-footer">
          <p className="card__read"> Leer mas...</p>
          <span className="card__number">37</span>
          <i class="fas fa-heart"></i>
        </footer>
      </div>
    );
  }
}

export default MediaCard;